import javafx.scene.shape.Circle;
import javafx.scene.paint.Color;

public class Shot extends Circle{
double x, y, radius;
	public Shot() {
		super();
		radius = 5;
		setRadius(5);
		setFill(Color.BLACK);
		setVisible(false);
	}
	
	public void fireShot(double rectX, double rectY) {
		x = rectX + 5;
		y = rectY - 2.5;
		setCenterX(x);
		setCenterY(y);
		setVisible(true);
	}
	public boolean move(double h, double w) {
		y -= 4;
		if(x < 0 || x > (w-radius) || y < 0){
			setVisible(false);
			return false;
		}
		else {
			setVisible(true);
			setCenterY(y);	
			return true;
		}
	}
}

