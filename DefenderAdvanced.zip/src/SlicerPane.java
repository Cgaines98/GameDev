import java.io.File;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Slider;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;


public class SlicerPane extends Pane {
	private Timeline animation;
	private double count = 10;
	private Rectangle ninja = new Rectangle(10,50);
	private Circle[] obstacles = new Circle[100];
	private Circle boss;
	private Shot[] shots= new Shot[100];
	private int[] obY = new int[100];
	private Stage setupStage;
	private double spawnRate, score;
	private int n, k, miss, hit, bossHit, size;
	private Label gameInfo;
	private Font regular = new Font("Arial Black", 18);
	private boolean done;
	

	  AudioClip backSound = new AudioClip(new File("src/audio/ambient.wav").toURI().toString());
	  AudioClip missAC = new AudioClip(new File("src/audio/miss.wav").toURI().toString());
	  AudioClip miss5 = new AudioClip(new File("src/audio/miss5.wav").toURI().toString());
	  AudioClip shotHit = new AudioClip(new File("src/audio/shotHit.wav").toURI().toString());
	  AudioClip fired = new AudioClip(new File("src/audio/fired.wav").toURI().toString());
	  AudioClip bossAC = new AudioClip(new File("src/audio/boss.wav").toURI().toString());
	  AudioClip beatBoss = new AudioClip(new File("src/audio/beatBoss.wav").toURI().toString());
	
	
	  
	public SlicerPane() {
		gameInfo = new Label();
		gameInfo.setTextFill(Color.DARKCYAN);
		gameInfo.setFont(regular);
		setMaxWidth(700);
		setMaxHeight(400);
		setMinWidth(700);
		setMinHeight(400);
		setStyle("-fx-border-color: cyan");
		
		n = 0;
		k = 0;
		miss =0;
		hit = 0;
		score = 0;
		spawnRate =5;
		size = 100;
	
		done = false;
		ninja.setStroke(Color.AZURE);
		ninja.setX(350);
		ninja.setY(350);
		ninja.setFill(Color.BLACK);
		boss = new Circle();
		boss.setRadius(20);
		boss.setCenterX(randomNumbers(100,600));
		boss.setCenterY(20);
		boss.setFill(Color.ORANGERED);
		boss.setVisible(false);
		
	
	for(int i = 0; i<size;i++) { 
		obstacles[i] = new Circle();
		obstacles[i].setRadius(8);
		obstacles[i].setVisible(false);
		obY[i] = 1;
		shots[i] = new Shot();
		
		}

	 animation = new Timeline(
		      new KeyFrame(Duration.millis(50), e -> moveObstacles()));
		    animation.setCycleCount(Timeline.INDEFINITE);
		    animation.play(); 
		   
	}
	
	public void moveObstacles() {
	count -= spawnRate;;
	
		if (count <= 0 && n < (size - 1)) {
	
		n++;
		obstacles[n].setCenterX(randomNumbers(20,700));
		obstacles[n].setCenterY(15);
		obstacles[n].setFill(Color.DARKRED);
		obstacles[n].setVisible(true);
		count = 200;
	}
	for(int i = 0; i<n +1; i++) {
		obY[i] += 2;
		obstacles[i].setCenterY(obY[i]);
		if(obstacles[i].getCenterY() > 400 && obstacles[i].isVisible()) {
			
			miss++;
			missAC.play();
			obstacles[i].setVisible(false);
				if(miss ==5) {
					miss5.play();
					animation.pause();
					endGame();
			}	
		}
	}
	for(int i = 0; i < (size -1); i++) {
		if (shots[i].isVisible()) {
			if (shots[i].move(400,700))
				checkHit(shots[i],0);	
		}
	
	}
	if (n == (size - 2))bossAC.play();
	if(n>=(size - 1) && checkVisibility() == true) {		
		boss.setVisible(true);
		boss.setCenterY(boss.getCenterY() + 4);
		for(int l = 0; l < size; l++) {
			if (shots[l].isVisible()) {
				if (shots[l].move(400,700))
					checkHit(shots[l],1);
					}				
				}
		if(boss.getCenterY()>400)
				endGame();
			}
	updateLabel();
}
	public boolean checkVisibility() {
		boolean b = false;
		for( int i = 0; i<size; i++){
			if(obstacles[i].isVisible() == false) {
				b = true;
			}
			else b = false;
		}
		return b;
	}
	protected boolean hit(Shot s, Circle c, int choice) {
		double sx = s.getCenterX();
		double sy = s.getCenterY();
		
		if (choice == 0) {
			if((sy + 8) >= c.getCenterY() && (sy - 8) <= (c.getCenterY()) && (sx + 8) >= c.getCenterX() && (sx - 8) <= c.getCenterX()) {
			return true;
			}
			return false;
		}
		else {
			if((sy + 20) >= c.getCenterY() && (sy - 20) <= (c.getCenterY()) && (sx + 20) >= c.getCenterX() && (sx - 20) <= c.getCenterX()) {
				bossHit++;
				return true;			
				}
				return false;
		}		
	}
	
	
	protected void checkHit(Shot s, int choice){
	if (choice == 0) {
		for(int i = 0; i < (size ); i++) {
			if(obstacles[i].isVisible() && hit(s,obstacles[i],0)) {
				hit ++;
				shotHit.play();
				obstacles[i].setVisible(false);
				s.setVisible(false);
				score += spawnRate * (spawnRate/10);
				}
			}
		}
	else {
		
			if(boss.isVisible() && hit(s,boss,1)) {

				shotHit.play();
				s.setVisible(false);
				if(bossHit == 5) {
					beatBoss.play();
					boss.setVisible(false);
					score += (spawnRate * size)/10;
					endGame();
				}
				
				}
			}
		}
	
	
	public void moveR() {
		if(ninja.getX()<690)
			ninja.setX(ninja.getX() + 10);
	}
	
	public void moveL() {
		if(ninja.getX()>1)
			ninja.setX(ninja.getX() - 10);
	}
	
	public static int randomNumbers (int max, int min) {
		int randomInt = min + (int)(Math.random() * ((max - min) + 1));
		return randomInt;
	}
	 public void play() {
		    animation.play();
		  }

	 public void pause() {
		    animation.pause();
		  }
	 public void begin(){
			n = 0;
			k = 0;
			miss =0;
			hit = 0;
			score = 0;
			spawnRate =5;
			size = 100;

		  	setupStage = new Stage();
		    setupStage.setTitle("Welcome to Defender"); 
		    for(int i = 0; i<size; i++) {
		    	getChildren().add(obstacles[i]);
		    }
		    getChildren().add(ninja);
		    getChildren().addAll(shots);
		    getChildren().add(boss);
		
		  
		
		    setupStage.setScene(new Scene(new Setup()));
		    setupStage.showAndWait();
		  
	 }
	 public void updateVolume(int choice, double sliderValue) {
		 switch(choice) {
		 case 1:	backSound.setVolume(sliderValue/150);
		 			
		 	break;
		 case 2:  	missAC.setVolume(sliderValue/150);
		 			miss5.setVolume(sliderValue/150);
		 			fired.setVolume(sliderValue/150);
		 			shotHit.setVolume(sliderValue/150);
		 			bossAC.setVolume(sliderValue/150);
		 			beatBoss.setVolume(sliderValue/150);
		 			
		 	break;
		 }
	 }
	 public void updateDiff(double slD) {
		 spawnRate = slD;
	 }
	 public void shoot() {
		 k++;
		 fired.play();
		 if(k > (size -1)) {
				k = 0;
		 }
		 shots[k].fireShot(ninja.getX(),ninja.getY());
	 }
	  public void updateLabel() {
		gameInfo.setText("Current Score: " + String.format("%2.2f", score) + "\tHits: " + hit + "  Missed: " + miss + "\tSpawn rate: " + String.format("%2.1f", (200/(spawnRate*20))) + " Seconds");
	  }
	  
	public Label getInfo() {
		return gameInfo;
	}
	
	public void endGame() {
		done = true;
		animation.pause();
		bossAC.stop();
		backSound.stop();
		
		 Alert alert = new Alert(AlertType.INFORMATION);
		  alert.setContentText("Final Score:  " + String.format("%2.2f", score));
		  alert.setTitle("Thanks For Playing!");
		  alert.setHeaderText("GG! Press okay to play again with extra enemies and faster spawn times");
		  alert.setOnHidden(event -> resetGame());
		  alert.show();
	}
	public boolean getDone() {
		return done;
	}
	
	public void resetGame() {
		n = 0;
		k = 0;
		miss =0;
		hit = 0;
		score = 0;
		bossHit = 0;
		spawnRate *= 1.2;
		if (size <=90)
				size += 10;
		done = false;
		beatBoss.stop();
		
		ninja.setStroke(Color.AZURE);
		ninja.setX(350);
		ninja.setY(350);
		boss.setCenterX(randomNumbers(100,600));
		boss.setCenterY(20);
		boss.setVisible(false);
			
	for(int i = 0; i<(size - 1);i++) { 
		obstacles[i].setCenterX(randomNumbers(10,690));
		obstacles[i].setCenterY(10);
		obstacles[i].setRadius(8);
		obstacles[i].setVisible(false);
		obY[i] = 1;
		shots[i].setVisible(false);
		
	}
animation.play();
backSound.play();
	}

	 class Setup extends GridPane{
			Button btAdd = new Button("Start Game");
			Label instructions = new Label("Left and Right to move\nSpacebar to shoot\nHit as many falling objects as possible\nIf you miss 5 the game is over");
			Label colorChoice = new Label("Choose your color");
			Label indexChoice = new Label("Number of enemies");
			private Font regular = new Font("Times New Roman", 14);
			
		    Setup(){
		    	animation.pause();
		    	instructions.setFont(regular);
		    	colorChoice.setFont(regular);
		    	indexChoice.setFont(regular);
			  	  getColumnConstraints().add(new ColumnConstraints(225)); // column 0 is 200 wide
				  getColumnConstraints().add(new ColumnConstraints(400)); //column 1 is 400 wide
				  getColumnConstraints().add(new ColumnConstraints(200));

			    	setPadding(new Insets(7));
			        setHgap(5.5);
			        setVgap(5.5);
			        
			        RadioButton t15 = new RadioButton("15");
			        RadioButton t25 = new RadioButton("25");
			        RadioButton t50 = new RadioButton("50");
			        ToggleGroup indextg = new ToggleGroup();
			        t15.setFont(regular);
			        t25.setFont(regular);
			        t50.setFont(regular);
			        t15.setToggleGroup(indextg);
			        t25.setToggleGroup(indextg);
			        t50.setToggleGroup(indextg);
			        EventHandler<ActionEvent> indexHandler = e -> {
			        	if(t15.isSelected())
			        			size= 15;
			        	else if(t25.isSelected())
			        			size = 25;
			        	else if(t50.isSelected())
			        		size = 50;
			        };
			        t15.setOnAction(indexHandler);
			        t25.setOnAction(indexHandler);
			        t50.setOnAction(indexHandler);

			        RadioButton green = new RadioButton("Green");
			        RadioButton blue = new RadioButton("Blue");
			        RadioButton purple = new RadioButton("Purple");
			        ToggleGroup colortg = new ToggleGroup();
			        green.setFont(regular);
			        blue.setFont(regular);
			        purple.setFont(regular);
			        green.setToggleGroup(colortg);
			        blue.setToggleGroup(colortg);
			        purple.setToggleGroup(colortg);
			        EventHandler<ActionEvent> colorHandler = e -> {
			        	if (blue.isSelected())
			        		ninja.setFill(Color.BLUE);
			        		else if(green.isSelected())
			        			ninja.setFill(Color.GREEN);
			        		else if(purple.isSelected())
			        			ninja.setFill(Color.PURPLE);
			        };
			        blue.setOnAction(colorHandler);
			        green.setOnAction(colorHandler);
			        purple.setOnAction(colorHandler);
			        
			    	Label FX = new Label("Sound effects");
			    	Slider slFX = new Slider(0,100,100);
			    	slFX.setShowTickLabels(true);
			    	FX.setFont(regular);
			        slFX.setShowTickMarks(true);
			        slFX.setMajorTickUnit(10);
			        slFX.setMinorTickCount(1);
			        slFX.setSnapToTicks(true);
			    	slFX.valueProperty().addListener(sov ->{
			    		updateVolume(2,slFX.getValue());
			    	});
			    	
			    	Label ambient = new Label("Background music");
			    	Slider slAmbient = new Slider(0,100,100);
			    	slAmbient.setShowTickLabels(true);
			    	ambient.setFont(regular);
			        slAmbient.setShowTickMarks(true);
			        slAmbient.setMajorTickUnit(10);
			        slAmbient.setMinorTickCount(1);
			        slAmbient.setSnapToTicks(true);
			    	slAmbient.valueProperty().addListener(sov ->{
			    		updateVolume(1,slAmbient.getValue());
			    	});
			    	
			    	Label difficulty = new Label("Difficulty(spawn rate)");
			    	Slider slD = new Slider(1,10,5);
			    	difficulty.setFont(regular);
			    	slD.setShowTickLabels(true);
			        slD.setShowTickMarks(true);
			        slD.setMajorTickUnit(1);
			        slD.setMinorTickCount(1);
			        slD.setSnapToTicks(true);
			    	slD.valueProperty().addListener(sov ->{
			    		updateDiff(slD.getValue());
			    	});
		    	Button btAdd = new Button("Start Game");
		    	btAdd.setOnAction((ActionEvent e) -> {
		    		animation.play();
		    		backSound.play();
		    		setupStage.close();
		        });
		    add(instructions,0,1);	
		    add(btAdd,1,16);
		    add(slFX,1,10);
		    add(FX,0,10);
		    add(difficulty,0,5);
		    add(slD, 1, 5);
		    add(ambient, 0, 7);
		    add(slAmbient,1,7);
		    add(green, 1,4);
		    add(blue,1,2);
		    add(purple, 1,3);
		    add(colorChoice,1,1);
		    add(t15, 2,4);
		    add(t25, 2,3);
		    add(t50, 2,2);
		    add(indexChoice,2,1);

		    }
	 }
	 
}
