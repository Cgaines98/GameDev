


import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;


public class GameControl extends Application {
  @Override 
  public void start(Stage primaryStage) {
    SlicerPane slicerPane = new SlicerPane(); 
    BorderPane mainPane = new BorderPane();
    HBox messagePane = new HBox();
    messagePane.getChildren().add(slicerPane.getInfo());
    messagePane.setStyle("-fx-background-color: #795548;");
    messagePane.setMaxHeight(50);
    messagePane.setMinHeight(50);
    messagePane.setMaxWidth(700);
    messagePane.setMinWidth(700);
    mainPane.setTop(slicerPane);
    mainPane.setBottom(messagePane);
    mainPane.setMinWidth(700);
	mainPane.setMaxWidth(700);
	mainPane.setMinHeight(450);
	mainPane.setMaxHeight(450);


 
	slicerPane.setOnMousePressed(e -> slicerPane.pause());
	slicerPane.setOnMouseReleased(e -> slicerPane.play());

    
    slicerPane.setOnKeyPressed(e -> {
      if (e.getCode() == KeyCode.RIGHT) {
        slicerPane.moveR();
      } 
      else if (e.getCode() == KeyCode.LEFT) {
        slicerPane.moveL();
      }
      else if (e.getCode() == KeyCode.SPACE) {
        if(slicerPane.getDone() == false)
    	  slicerPane.shoot();
      }

    });
    slicerPane.begin();
    
    Scene scene = new Scene(mainPane);
    primaryStage.setTitle("Victory awaits"); 
    primaryStage.setScene(scene); 
    primaryStage.show(); 
    
  
    slicerPane.requestFocus();
  }


  public static void main(String[] args) {
    launch(args);
  }
}
